package cz.vsb.p4.testapp;

/**
 * Created by trehak on 10.10.2016.
 */
public class CounterValue {

    private final Integer value;

    public CounterValue(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }

}
